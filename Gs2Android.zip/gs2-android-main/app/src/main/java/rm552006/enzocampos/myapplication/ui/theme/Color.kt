package rm552006.enzocampos.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta azul
val Blue80 = Color(0xFF90CAF9)
val BlueGrey80 = Color(0xFF81D4FA)
val LightBlue80 = Color(0xFFB3E5FC)

val Blue40 = Color(0xFF1E88E5)
val BlueGrey40 = Color(0xFF0288D1)
val LightBlue40 = Color(0xFF03A9F4)